package org.codehaus.jackson.map.deser;

/**
 * @deprecated Since 1.9, use {@link org.codehaus.jackson.map.deser.std.StdKeyDeserializers} instead.
 */
@Deprecated
class StdKeyDeserializers
    extends org.codehaus.jackson.map.deser.std.StdKeyDeserializers
{
    protected StdKeyDeserializers() { super(); }
}
